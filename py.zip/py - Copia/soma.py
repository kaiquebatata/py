x=6
x=x+1
print("O Resultado de x é igual a",x)
