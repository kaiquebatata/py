a = (input("Digite o valor de a:"))
b = (input("Digite o valor de b:"))
c = (input("Digite o valor de c:"))

if a> b and c>b:
    print("O menor valor é o b")