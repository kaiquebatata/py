a=10
b=20
c=30
total=(a+b)*c
print(total)

d =42
e =30
total2=(d/e)
print(total2)

f =94 
g =2
h =6
i =1
total3 =((f+g)*h-1)
print(total3)
