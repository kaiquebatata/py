a = 33
b = 33

if b>a:
    print("b é maior que a")
    elif a == b:
    print("a and b are equal")
else:
    print("a é maior que b")