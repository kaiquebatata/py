import math
num = float(input("Digite um número: "))
resultado = math.sqrt(num)
print("O valor da raiz quadrada é:",resultado)