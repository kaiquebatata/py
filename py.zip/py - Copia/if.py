a = 33
b = 200

if b>a:
    print("b é maior que a")